import MergeSortVisualizer from './MergeSortVisualizer/MergeSortVisualizer';
import './App.css';

function App() {
  return (
  <div className="App">
    <MergeSortVisualizer></MergeSortVisualizer>
  </div>
  );
}

export default App;